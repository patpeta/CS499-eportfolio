package com.example.petathompsoninventoryfp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SmsActivity extends AppCompatActivity {

    private Button requestSmsPermissionButton;
    private TextView permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Match XML IDs EXACTLY
        requestSmsPermissionButton = findViewById(R.id.requestSmsPermissionButton);
        permissionStatus = findViewById(R.id.permissionStatus);

        requestSmsPermissionButton.setOnClickListener(v -> {
            // Simple placeholder (you can upgrade this later)
            permissionStatus.setText("SMS permission request triggered");
        });
    }
}