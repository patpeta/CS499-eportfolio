package com.example.petathompsoninventoryfp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class HomeActivity extends AppCompatActivity {

    private ArrayList<Item> fullItemList;
    private ArrayList<Item> displayedItemList;
    private InventoryListAdapter adapter;

    private int selectedIndex = -1;

    private EditText updateNameInput;
    private EditText updateQuantityInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ListView inventoryListView = findViewById(R.id.inventoryListView);
        SearchView searchView = findViewById(R.id.searchView);

        updateNameInput = findViewById(R.id.updateNameInput);
        updateQuantityInput = findViewById(R.id.updateQuantityInput);

        Button addItemButton = findViewById(R.id.addItemButton);
        Button updateItemButton = findViewById(R.id.updateItemButton);
        Button deleteItemButton = findViewById(R.id.deleteItemButton);
        Button sortButton = findViewById(R.id.sortButton);
        Button signOutButton = findViewById(R.id.signOutButton);

        fullItemList = InventoryStorage.loadItems(this);
        displayedItemList = new ArrayList<>(fullItemList);

        adapter = new InventoryListAdapter(this, displayedItemList, item -> {
            fullItemList.remove(item);
            displayedItemList.remove(item);

            InventoryStorage.saveItems(this, fullItemList);
            adapter.notifyDataSetChanged();

            selectedIndex = -1;
            updateNameInput.setText("");
            updateQuantityInput.setText("");

            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        });

        inventoryListView.setAdapter(adapter);

        inventoryListView.setOnItemClickListener((parent, view, position, id) -> {
            selectedIndex = position;

            Item selectedItem = displayedItemList.get(position);
            updateNameInput.setText(selectedItem.getName());
            updateQuantityInput.setText(String.valueOf(selectedItem.getQuantity()));

            Toast.makeText(this, "Selected: " + selectedItem.getName(), Toast.LENGTH_SHORT).show();
        });

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, NewItemActivity.class);
            startActivity(intent);
        });

        updateItemButton.setOnClickListener(v -> updateSelectedItem());
        deleteItemButton.setOnClickListener(v -> deleteSelectedItem());

        sortButton.setOnClickListener(v -> {
            Collections.sort(fullItemList, (item1, item2) ->
                    item1.getName().compareToIgnoreCase(item2.getName())
            );

            InventoryStorage.saveItems(this, fullItemList);
            refreshDisplayedList("");
            Toast.makeText(this, "Inventory sorted", Toast.LENGTH_SHORT).show();
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                refreshDisplayedList(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                refreshDisplayedList(newText);
                return true;
            }
        });

        signOutButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        fullItemList.clear();
        fullItemList.addAll(InventoryStorage.loadItems(this));

        refreshDisplayedList("");
    }

    private void refreshDisplayedList(String searchText) {
        displayedItemList.clear();

        for (Item item : fullItemList) {
            if (item.getName().toLowerCase().contains(searchText.toLowerCase())) {
                displayedItemList.add(item);
            }
        }

        selectedIndex = -1;
        updateNameInput.setText("");
        updateQuantityInput.setText("");

        adapter.notifyDataSetChanged();
    }

    private void updateSelectedItem() {
        if (selectedIndex == -1) {
            Toast.makeText(this, "Select an item first", Toast.LENGTH_SHORT).show();
            return;
        }

        Item selectedItem = displayedItemList.get(selectedIndex);

        String name = updateNameInput.getText().toString().trim();
        String quantityText = updateQuantityInput.getText().toString().trim();

        if (name.isEmpty()) {
            updateNameInput.setError("Item name is required");
            return;
        }

        if (quantityText.isEmpty()) {
            updateQuantityInput.setError("Quantity is required");
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            updateQuantityInput.setError("Enter a valid number");
            return;
        }

        selectedItem.setName(name);
        selectedItem.setQuantity(quantity);

        InventoryStorage.saveItems(this, fullItemList);
        adapter.notifyDataSetChanged();

        selectedIndex = -1;
        updateNameInput.setText("");
        updateQuantityInput.setText("");

        Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
    }

    private void deleteSelectedItem() {
        if (selectedIndex == -1) {
            Toast.makeText(this, "Select an item first", Toast.LENGTH_SHORT).show();
            return;
        }

        Item selectedItem = displayedItemList.get(selectedIndex);

        fullItemList.remove(selectedItem);
        displayedItemList.remove(selectedItem);

        InventoryStorage.saveItems(this, fullItemList);
        adapter.notifyDataSetChanged();

        selectedIndex = -1;
        updateNameInput.setText("");
        updateQuantityInput.setText("");

        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
    }
}