package com.example.petathompsoninventoryfp;

import android.app.Activity;

public class SignoutActivity extends Activity {
}
