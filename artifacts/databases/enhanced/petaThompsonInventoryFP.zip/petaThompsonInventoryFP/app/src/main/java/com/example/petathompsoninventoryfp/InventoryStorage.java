package com.example.petathompsoninventoryfp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;

public class InventoryStorage {

    private static final String PREF_NAME = "InventoryPrefs";
    private static final String ITEM_COUNT_KEY = "item_count";

    public static void saveItems(Context context, ArrayList<Item> items) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.clear();
        editor.putInt(ITEM_COUNT_KEY, items.size());

        for (int i = 0; i < items.size(); i++) {
            editor.putString("item_name_" + i, items.get(i).getName());
            editor.putInt("item_quantity_" + i, items.get(i).getQuantity());
        }

        editor.apply();
    }

    public static ArrayList<Item> loadItems(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        ArrayList<Item> items = new ArrayList<>();

        int count = prefs.getInt(ITEM_COUNT_KEY, 0);

        for (int i = 0; i < count; i++) {
            String name = prefs.getString("item_name_" + i, "");
            int quantity = prefs.getInt("item_quantity_" + i, 0);

            if (!name.isEmpty()) {
                items.add(new Item(name, quantity));
            }
        }

        return items;
    }
}