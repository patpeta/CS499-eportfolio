package com.example.petathompsoninventoryfp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class NewItemActivity extends AppCompatActivity {

    private EditText nameInput;
    private EditText quantityInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newitem);

        nameInput = findViewById(R.id.itemNameInput);
        quantityInput = findViewById(R.id.itemQuantityInput);
        Button saveButton = findViewById(R.id.addItemButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        saveButton.setOnClickListener(v -> saveItem());
        cancelButton.setOnClickListener(v -> finish());
    }

    private void saveItem() {
        String itemName = nameInput.getText().toString().trim();
        String quantityText = quantityInput.getText().toString().trim();

        if (itemName.isEmpty()) {
            nameInput.setError("Item name is required");
            return;
        }

        if (quantityText.isEmpty()) {
            quantityInput.setError("Quantity is required");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            quantityInput.setError("Enter a valid number");
            return;
        }

        ArrayList<Item> items = InventoryStorage.loadItems(this);
        items.add(new Item(itemName, quantity));
        InventoryStorage.saveItems(this, items);

        Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
        finish();
    }
}