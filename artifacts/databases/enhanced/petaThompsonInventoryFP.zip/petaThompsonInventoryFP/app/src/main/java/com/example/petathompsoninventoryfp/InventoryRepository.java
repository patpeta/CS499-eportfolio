package com.example.petathompsoninventoryfp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class InventoryRepository {

    private static final ArrayList<Item> items = new ArrayList<>();

    static {
        items.add(new Item("Pens", 20));
        items.add(new Item("Paper", 50));
        items.add(new Item("Markers", 12));
    }

    public static void addItem(Item item) {
        items.add(item);
    }

    public static List<Item> getAllItems() {
        return new ArrayList<>(items);
    }

    public static List<Item> searchItems(String query) {
        ArrayList<Item> results = new ArrayList<>();

        for (Item item : items) {
            if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                results.add(item);
            }
        }

        return results;
    }

    public static List<Item> sortItemsByName() {
        ArrayList<Item> sortedItems = new ArrayList<>(items);

        Collections.sort(sortedItems, new Comparator<Item>() {
            @Override
            public int compare(Item first, Item second) {
                return first.getName().compareToIgnoreCase(second.getName());
            }
        });

        return sortedItems;
    }
}