package com.example.petathompsoninventoryfp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class InventoryListAdapter extends ArrayAdapter<Item> {

    public interface OnDeleteClickListener {
        void onDeleteClick(Item item);
    }

    private OnDeleteClickListener deleteClickListener;

    public InventoryListAdapter(Context context, List<Item> items, OnDeleteClickListener listener) {
        super(context, 0, items);
        this.deleteClickListener = listener;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.item_inventory, parent, false);
        }

        Item currentItem = getItem(position);

        TextView nameText = convertView.findViewById(R.id.itemNameText);
        TextView quantityText = convertView.findViewById(R.id.itemQuantityText);
        Button deleteButton = convertView.findViewById(R.id.deleteRowButton);

        if (currentItem != null) {
            nameText.setText(currentItem.getName());
            quantityText.setText("Quantity: " + currentItem.getQuantity());

            deleteButton.setOnClickListener(v -> {
                if (deleteClickListener != null) {
                    deleteClickListener.onDeleteClick(currentItem);
                }
            });
        }

        return convertView;
    }
}