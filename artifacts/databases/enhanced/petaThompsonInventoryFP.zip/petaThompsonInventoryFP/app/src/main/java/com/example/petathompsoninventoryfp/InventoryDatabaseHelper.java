package com.example.petathompsoninventoryfp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_ITEMS = "items";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_QUANTITY = "quantity";

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable =
                "CREATE TABLE " + TABLE_ITEMS + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_NAME + " TEXT NOT NULL UNIQUE, " +
                        COLUMN_QUANTITY + " INTEGER NOT NULL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    public boolean addItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());

        long result = db.insert(TABLE_ITEMS, null, values);
        db.close();

        return result != -1;
    }

    public ArrayList<Item> getAllItems() {
        ArrayList<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_ITEMS,
                null,
                null,
                null,
                null,
                null,
                COLUMN_NAME + " ASC"
        );

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));

                itemList.add(new Item(name, quantity));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return itemList;
    }

    public int getQuantity(String itemName) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_QUANTITY + " FROM " + TABLE_ITEMS + " WHERE " + COLUMN_NAME + " = ?",
                new String[]{itemName}
        );

        int quantity = 0;

        if (cursor.moveToFirst()) {
            quantity = cursor.getInt(0);
        }

        cursor.close();
        db.close();

        return quantity;
    }

    public boolean updateItemQuantity(String itemName, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);

        int rowsUpdated = db.update(
                TABLE_ITEMS,
                values,
                COLUMN_NAME + " = ?",
                new String[]{itemName}
        );

        db.close();

        return rowsUpdated > 0;
    }

    public boolean increaseQuantity(String itemName) {
        int currentQuantity = getQuantity(itemName);
        return updateItemQuantity(itemName, currentQuantity + 1);
    }

    public boolean decreaseQuantity(String itemName) {
        int currentQuantity = getQuantity(itemName);

        if (currentQuantity <= 0) {
            return false;
        }

        return updateItemQuantity(itemName, currentQuantity - 1);
    }

    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_ITEMS,
                COLUMN_NAME + " = ?",
                new String[]{itemName}
        );

        db.close();

        return rowsDeleted > 0;
    }
}