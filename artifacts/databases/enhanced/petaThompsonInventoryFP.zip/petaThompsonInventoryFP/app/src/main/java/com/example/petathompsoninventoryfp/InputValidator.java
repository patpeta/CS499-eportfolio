package com.example.petathompsoninventoryfp;
//add validator for added security
public class InputValidator {

    public static boolean isValidText(String input) {
        return input != null && !input.trim().isEmpty();
    }

    public static boolean isValidNumber(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}