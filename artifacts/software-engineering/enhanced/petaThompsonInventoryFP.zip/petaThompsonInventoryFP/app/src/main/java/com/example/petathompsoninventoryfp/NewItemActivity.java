package com.example.petathompsoninventoryfp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewItemActivity extends AppCompatActivity {

    private EditText nameInput;
    private EditText quantityInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Corrected layout name
        setContentView(R.layout.activity_newitem);

        // Match XML IDs
        nameInput = findViewById(R.id.itemNameInput);
        quantityInput = findViewById(R.id.itemQuantityInput);
        Button saveButton = findViewById(R.id.addItemButton);

        saveButton.setOnClickListener(v -> handleSave());
    }

    private void handleSave() {
        String itemName = nameInput.getText().toString();
        String quantityStr = quantityInput.getText().toString();

        if (!validateInput(itemName, quantityStr)) {
            return;
        }

        int quantity = Integer.parseInt(quantityStr);

        // Now works because Item class exists
        Item item = new Item(itemName, quantity);

        showToast("Item saved: " + item.getName());

        clearInputs();
    }

    private boolean validateInput(String name, String quantity) {

        if (!InputValidator.isValidText(name)) {
            showToast("Item name is required");
            return false;
        }

        if (!InputValidator.isValidNumber(quantity)) {
            showToast("Enter a valid quantity");
            return false;
        }

        return true;
    }

    private void clearInputs() {
        nameInput.setText("");
        quantityInput.setText("");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}