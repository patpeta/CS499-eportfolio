package com.example.petathompsoninventoryfp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private Button addItemButton;
    private Button smsScreenButton;
    private Button signOutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //  Match XML IDs
        addItemButton = findViewById(R.id.addItemButton);
        smsScreenButton = findViewById(R.id.smsScreenButton);
        signOutButton = findViewById(R.id.signOutButton);

        // Open Add Item screen
        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, NewItemActivity.class);
            startActivity(intent);
        });

        // Open SMS screen
        smsScreenButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        // Sign out
        signOutButton.setOnClickListener(v -> {
            finish();
        });
    }
}