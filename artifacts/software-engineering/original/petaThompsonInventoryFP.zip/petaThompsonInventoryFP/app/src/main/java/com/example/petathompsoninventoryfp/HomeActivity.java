package com.example.petathompsoninventoryfp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btnNewItem = findViewById(R.id.btnNewItem);
        Button btnSms = findViewById(R.id.btnSms);
        Button btnSignOut = findViewById(R.id.btnSignOut);

        btnNewItem.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, NewitemActivity.class))
        );

        btnSms.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, SmsActivity.class))
        );

        btnSignOut.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, MainActivity.class))
        );
    }
}
