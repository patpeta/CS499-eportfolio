package com.example.petathompsoninventoryfp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NewitemActivity extends AppCompatActivity {
    private EditText itemName, itemQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newitem);

        itemName = findViewById(R.id.itemName);
        itemQuantity = findViewById(R.id.itemQuantity);
        Button addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(v -> {
            String name = itemName.getText().toString().trim();
            String qty = itemQuantity.getText().toString().trim();

            if (name.isEmpty() || qty.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item added: " + name + " (" + qty + ")", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
