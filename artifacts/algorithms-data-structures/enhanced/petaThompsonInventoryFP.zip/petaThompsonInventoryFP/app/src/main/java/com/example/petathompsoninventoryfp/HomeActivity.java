package com.example.petathompsoninventoryfp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HomeActivity extends AppCompatActivity {

    private InventoryAdapter inventoryAdapter;
    private EditText searchInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        RecyclerView inventoryList = findViewById(R.id.inventoryList);
        searchInput = findViewById(R.id.searchInput);
        Button searchButton = findViewById(R.id.searchButton);
        Button sortButton = findViewById(R.id.sortButton);
        Button addItemButton = findViewById(R.id.addItemButton);
        Button smsScreenButton = findViewById(R.id.smsScreenButton);
        Button signOutButton = findViewById(R.id.signOutButton);

        inventoryList.setLayoutManager(new LinearLayoutManager(this));
        inventoryAdapter = new InventoryAdapter(InventoryRepository.getAllItems());
        inventoryList.setAdapter(inventoryAdapter);

        searchButton.setOnClickListener(v -> performSearch());
        sortButton.setOnClickListener(v ->
                inventoryAdapter.updateItems(InventoryRepository.sortItemsByName())
        );

        addItemButton.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, NewItemActivity.class))
        );

        smsScreenButton.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, SmsActivity.class))
        );

        signOutButton.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, MainActivity.class))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        inventoryAdapter.updateItems(InventoryRepository.getAllItems());
    }

    private void performSearch() {
        String query = searchInput.getText().toString().trim();

        if (query.isEmpty()) {
            inventoryAdapter.updateItems(InventoryRepository.getAllItems());
        } else {
            inventoryAdapter.updateItems(InventoryRepository.searchItems(query));
        }
    }
}