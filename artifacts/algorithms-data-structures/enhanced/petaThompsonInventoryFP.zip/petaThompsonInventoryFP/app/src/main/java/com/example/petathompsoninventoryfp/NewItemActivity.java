package com.example.petathompsoninventoryfp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewItemActivity extends AppCompatActivity {

    private EditText itemNameInput;
    private EditText itemQuantityInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newitem);

        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        Button addItemButton = findViewById(R.id.addItemButton);

        addItemButton.setOnClickListener(v -> saveItem());
    }

    private void saveItem() {
        String name = itemNameInput.getText().toString().trim();
        String quantityText = itemQuantityInput.getText().toString().trim();

        if (name.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException exception) {
            Toast.makeText(this, "Enter a valid quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        InventoryRepository.addItem(new Item(name, quantity));
        Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
        finish();
    }
}